var viewer;
            
function onSelectChange(){
	var selected = $("#grafos option:selected");
          	
  $.getJSON('estadisticas.json',
  function(data){
  	$.each(data.graphs, function(i, item){
	    if(selected.val() == item.name){
        //sigma

        $('#sigma-example').empty();
        paintViewer(item.browsegraph)

	    	
        $("#tituloGrafico").html(item.title);
	    	
	    	if(item.tip != ""){
	    		$("#hallazgos").html(item.tip);
	    	}
	    	
	    	$("#nodesValue").html(item.nodes);
	      $("#edgesValue").html(item.edges);
	      $("#descriptionValue").html(item.description);
	      
	      if(item.imgColorDescription != ""){
	      	$("#descriptionValue").append("<br/><img src='" + item.imgColorDescription + "' />");
	      }
	      
	      $("#averageDegreeValue").html(item.avgdegree);
	      $("#avgWeightedDegree").html(item.avgweighteddegree);
	      $("#densityValue").html(item.density);

	      $("#fileGraphValue").html("<a href='"+item.graphfile+"'>Graph</a>");
	      $("#filePdfValue").html("<a href='"+item.pdffile+"' target='_blank'>Image (PDF)</a>");
	      
        $("#descargar").attr("href", item.pdffile);
        $("#downloadCSV").attr("href", item.graphfile);
	    }
	  });
	  $.closeAllWindows();
  });
}
function paintViewer(gexfPath){
  viewer = sigma.init(document.getElementById('sigma-example')).drawingProperties({
    defaultLabelColor: '#fff',
    defaultLabelSize: 14,
    defaultLabelBGColor: '#fff',
    defaultLabelHoverColor: '#000',
    labelThreshold: 1,
    defaultEdgeType: 'curve'
  }).graphProperties({
    minNodeSize: 0.5,
    maxNodeSize: 5,
    minEdgeSize: 1,
    maxEdgeSize: 1
  }).mouseProperties({
    maxRatio: 32
  });
  viewer.parseGexf(gexfPath);
  var greyColor = '#666';
  viewer.bind('overnodes',function(event){
    var nodes = event.content;
    var neighbors = {};
    viewer.iterEdges(function(e){
      if(nodes.indexOf(e.source)<0 && nodes.indexOf(e.target)<0){
        if(!e.attr['grey']){
          e.attr['true_color'] = e.color;
          e.color = greyColor;
          e.attr['grey'] = 1;
        }
      }else{
        e.color = e.attr['grey'] ? e.attr['true_color'] : e.color;
        e.attr['grey'] = 0;
 
        neighbors[e.source] = 1;
        neighbors[e.target] = 1;
      }
    }).iterNodes(function(n){
      if(!neighbors[n.id]){
        if(!n.attr['grey']){
          n.attr['true_color'] = n.color;
          n.color = greyColor;
          n.attr['grey'] = 1;
        }
      }else{
        n.color = n.attr['grey'] ? n.attr['true_color'] : n.color;
        n.attr['grey'] = 0;
      }
    }).draw(2,2,2);
  }).bind('outnodes',function(){
    viewer.iterEdges(function(e){
      e.color = e.attr['grey'] ? e.attr['true_color'] : e.color;
      e.attr['grey'] = 0;
    }).iterNodes(function(n){
      n.color = n.attr['grey'] ? n.attr['true_color'] : n.color;
      n.attr['grey'] = 0;
    }).draw(2,2,2);
  });
  
  viewer.draw();  
}
            
function start(path) {  
  onSelectChange();
}

function configView(valor){
	$('#grafos').val(valor).attr('selected', 'selected');
  onSelectChange();
}

function verEstadisticas(){
	$.newWindow({title:"Stats",
							 content:$('#estadisticasDiv').html(),
							 posx:820,posy:200,width:500,height:400});
}